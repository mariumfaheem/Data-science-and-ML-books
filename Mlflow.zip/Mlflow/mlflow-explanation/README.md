when we run this code first time we got 

![img.png](img.png)


whenever we run the code , it create one more artificate
everytime it create new version of ML model

![img_1.png](img_1.png)

noe see what is inside the particular folder
![img_2.png](img_2.png)


- model.pkl is basically serialize pkl file
![img_3.png](img_3.png)

- conda.yaml basically shows dependencies 


we can also access Mlflow UI
![img_4.png](img_4.png)

so here we can see 10 times i train my model , along with runtime , starttime start 
![img_5.png](img_5.png)

![img_6.png](img_6.png)

artificate is most important 
![img_7.png](img_7.png)

and most exciting thing is we can compare performance metric of each model
![img_8.png](img_8.png)