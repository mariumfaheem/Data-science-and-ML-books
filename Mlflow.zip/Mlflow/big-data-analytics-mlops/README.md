# Real-time and ML platform

Documentation for any technically complex real life project ( Data pipeline end to end with ML Ops for predictive analytics) with details on :

1) Goal and business use case/value of project

2) What made the project complex?

3) How did you solve the complexity? Explain technical details with architecture diagrams

4) Lessons

## Answer 1:

the goal of the project is to provide

- An advance analytical platform for data analyst
- A complete MLOPs system to enable data scientists and analyst

## Answer 2:

This was an in-house ml and analytical platform using all the cutting edges and advanced tech,

from data storage to capturing real-time data to providing data sets to analysts and building ML models.

This platform is based on many advanced tech stacks like

- **Data Meshes** on S3: the mesh is a micro-services of data here we place data from different sources in different places to make maintaining and governance easy
- **AWS Data Migration Service** Event logs captured for real-time and batch analysis
- **EKS Cluster** For Hosting opensource applications like Apache Airflow, query engine presto, BI tool Redash, MLFlow(For development, etc), Jupyter notebook for DS. it orchestrates containerized applications to run on a cluster of hosts
- **Apache Presto** Engine for data retrieval. Presto is an open source, distributed SQL query engine designed for fast, interactive queries on data in HDFS, s3, etc
- **Apache Airflow** is an open-source tool For orchestration and programmatically authoring scheduling and monitoring workflows. It is one of the most robust platforms used by Data Engineers for orchestrating workflows or pipelines.
- **Redash** enables anyone, regardless of the level of technical sophistication, to harness the power of data big and small. SQL users leverage Redash to explore, query, visualize, and share data from any data source. Their work in turn enables anybody in their organization to use the data.
- **EMR Clusters:** Amazon EMR is a cloud big data platform for processing large volumes
- **MLFlow:** MLflow for managing the end-to-end machine learning lifecycle

# Ans 3.

I’ve explain each step here with use case as well as diagram mentioned part;

# Data Source and capture Real-time data

When we talk about big data, it means various data sources, multi-format data , structure and unstructured data .In first step Application will update specific data that is stored on AWS RDS , then Data Migration service will capture data and place our into Data Mesh.

You may easily and securely move databases to AWS with the aid of AWS Database Migration Service (AWS DMS). Applications that rely on the source database experience the least amount of downtime during the migration since the source database is still fully functional. Your data may be transferred to and from the most popular commercial and open-source databases using the AWS Database Migration Service.

Amazon Data Migration Service makes it simple to gather, process, and analyze real-time streaming data, allowing you to get immediate insights and respond swiftly to new information. AWS DMS provides crucial features for cost-effectively processing streaming data at any scale, as well as the freedom to select the tools that best meet your application's needs. For machine learning, analytics, and other applications, you may use DMS to ingest real-time data like as video, audio, application logs, website clickstreams, and IoT telemetry data. Instead of needing to wait until all of your data is collected before processing can begin, AWS DMS allows you to process and analyse data as it arrives and respond instantaneously. and for consolidated data storage S3 is used .

![1.png](1.png)


here, we have different data sources, RDS(MySQL, Postgres), and other junk files we need to capture their real-time data with DMS and place into AWS Data meshes that is our s3 bucket

# **Data Mesh Architecture - Storage**

Our Data storage for real-time and batch data is s3.it has too many reasons to choose s3 as storage. As in the data lake, we stored data from different sources on a single point (in AWS it’s mostly S3). In data, the mesh is a microservice of data where we place data from different sources in different places to make maintaining and governance easy

S3, or Amazon Simple Storage Service, is a data storage service that offers excellent durability and availability. By default, S3 blocks access from most sources, much as other services. By default, read/write access is limited to bucket and object owners (the AWS account owner). To prevent unauthorized people from reading, uploading, or deleting your files, make sure your S3 buckets are locked down. Unlike other services, S3 allows you to add permissions in a variety of methods, including Within your AWS account, assigning IAM roles to individual users. They can be used to control who has access to S3 buckets and what they can do with them. Access Manage Lists are used to control access to AWS accounts rather than individual users. If your company has many AWS accounts, they are helpful.S3 - S3 is best known for Secure Your Object Store

![2.png](2.png)

So we captured data from RDS through DMS and stored data with respect to services in data meshes , now interesting point to notice is we are gonna stored data in parquet format instead of csv so why parquet ? so Apache Parquet is **an open source, column-oriented data file format designed for efficient data storage and retrieval**. It provides efficient data compression and encoding schemes with enhanced performance to handle complex data in bulk.

so in order to save cost and faster **retrieval we use Parquet format.**

![3.png](3.png)

# EMR and EKS For Computation

## 1-EMR

![4.png](4.png)

- After that Amazon Elastic MapReduce (Amazon EMR) is responsible to handle large volumes of data swiftly and cost-effectively. Amazon EMR is a cloud big data platform for processing large volumes of data with open source technologies including Apache Spark, Apache Hive, Apache HBase, Apache Flink, Apache Hudi, and Presto. By automating time-consuming operations like providing capacity and optimizing clusters, Amazon EMR makes it simple to set up, maintain, and scale your big data settings. It leverages Hadoop, an open source framework, to spread your data and processing over a resizable cluster of Amazon EC2 instances. Log analysis, web indexing, data warehousing, machine learning, financial analysis, scientific simulation, and bioinformatics are among the applications that employ Amazon EMR.EMR (Elastic Map Reduce), and Elastic Kubernetes (EKS) are Big Data Distributed Services. It means they use different EC2 machines to distribute data. since on this machine heavy lifting of data processing occurs, it’s essential to keep it secure as well.
- On EMR Cluster we installed tensor and other ML-related libraries to run and execute ML pipelines

### Storage For Real and Batch Job Design with EMR

- Using EMR Cluster we were running Apache spark and delta streamer that dump data again into our data meshes different layers, we have
1. Raw Layers
2. Bronze Layers
3. Gold layers

After attaching the data buckets, we move data to our based layer cleaning and governance process which is created using Delta streamer. We have three levels in this process

- **Raw Level** — unmodified data which reflects the actual data source state
- **Bronze Level** — governess and quality layer which enforces necessary compliance and provides the ability to clean, transform and filter data.
- **Gold Level** — this is the final state for our data life cycle where we create Data Products that are consumed by our end users

![5.png](5.png)

## 

## **Processing Layer**

This layer is super abstract, most of the time people creating the pipeline don’t know if the back-end data will be real-time or batch, this is achieved by using continuously running Delta Streamer which read data from both the buckets and Kafka topics and maintain MOR (merge-on-read) tables. Our main processing framework is Apache Spark, which works well for us.
![spark.png](spark.png)
## 2-Elastic Kubernetes Service (Amazon EKS)

To operate and grow Kubernetes applications in the cloud or on-premises, Amazon Elastic Kubernetes Service (Amazon EKS) is a managed container service.

## **Query Layer**

As all of our data reside in data buckets, we needed some sort of query engine to retrieve them, here Presto was a simple decision as we already had hands-on knowledge over it.

## orchestration and scheduling

- To schedule our data pipeline job we had to use airflow because **Apache Airflow** is an open-source tool For orchestration and programmatically authoring, scheduling, and monitoring workflows. It is one of the most robust platforms used by Data Engineers for orchestrating workflows or pipelines.

## BI and analyst Tool:

for the query and interface for dashboarding, on the top of k8s, we had configured redash . it was a self-managed tool so the purpose of redash is to enable anyone, regardless of the level of technical sophistication, to harness the power of data big and small. SQL users leverage Redash to explore, query, visualize, and share data from any data source. Their work in turn enables anybody in their organization to use the data

## For ML Deployments -  MLFlow

![6.png](6.png)

`Code is attached with folder and explanation is in [README.md](http://README.md) file`

on the top of the k8s cluster, we configure MLFlow.A central model registry, experimentation, reproducibility, and deployment are all managed through the open source platform MLflow. MLflow presently provides these four elements:

MLflow is an open source platform to manage the ML lifecycle, including experimentation, reproducibility, deployment, and a central model registry. The main advantage of including MLflow in your ML lifecycle is **the transparency and standardization it** brings to the table when it comes to training, tuning, and deploying ML models. It **lets you train, reuse, and deploy models with any library and package them into reproducible steps** that other data scientists can use as a “black box,” without even having to know which library you are using.

MLflow presently provides these four elements:

1. MLflow tracking
2. MlFlow projects
3. MLflow models
4. MLflow registry
5. Deployment automation
6. Model testing and many models

ML cycle diagram is attached here for simple understanding.

![7.png](7.png)

we build MLflow on the top of k8s, cluster using helm chart [https://artifacthub.io/packages/helm/larribas/mlflow](https://artifacthub.io/packages/helm/larribas/mlflow)

so here look into what each feature does

### **MLflow Tracking:**

MLflow Tracking is an API and UI for logging parameters, code versions, metrics, and output files when running your machine learning code to later visualize them. With a few simple lines of code, you can track parameters, metrics, and artifacts
![8.png](8.png)

![9.png](9.png)

### **MLflow Projects:**

Package data science code in a format to reproduce runs on any platform

![10.png](10.png)

### **MLflow Models**

Deploy machine learning models in diverse serving environments

![11.png](11.png)

### **Model Registry**

Store, annotate, discover, and manage models in a central repository

For a better understanding of how MLflow work I've attached a project(code, readme) that explains how we can train models and deployments step too

## Feature Storage - RDS, Redshift

Depending on your use case we can use RDS or redshift to store features

### For Reference and Implementation Helm charts:

- **Data Meshes** : [https://medium.com/@MariumFaheem/data-mesh-microservice-in-data-world-d6703ba5a1f3](https://medium.com/@MariumFaheem/data-mesh-microservice-in-data-world-d6703ba5a1f3)
- **AWS Data Migration Service** [https://aws.amazon.com/dms/](https://aws.amazon.com/dms/)
- **EKS Cluster** [https://docs.aws.amazon.com/eks/latest/userguide/clusters.html](https://docs.aws.amazon.com/eks/latest/userguide/clusters.html)
- **Apache Presto** [https://artifacthub.io/packages/helm/valeriano-manassero/presto](https://artifacthub.io/packages/helm/valeriano-manassero/presto)
- **Apache Airflow** [https://artifacthub.io/packages/helm/apache-airflow/airflow](https://artifacthub.io/packages/helm/apache-airflow/airflow)
- **Redash** [https://artifacthub.io/packages/helm/redash/redash/1.2.0](https://artifacthub.io/packages/helm/redash/redash/1.2.0)
- **EMR Clusters:** [https://aws.amazon.com/emr/](https://aws.amazon.com/emr/)
- **MLFlow:** [MLflow for managing the end-to-end machine learning lifecycle](https://artifacthub.io/packages/helm/larribas/mlflow)
- **AWS RDS**
- **AWS Load Balancer**

# Ans 4

since we used all the cutting edges and open source project so there is a learning curve of Kubernetes , EMR , helm chart , Platform engineer is also responsible to have understandings of ML life cycle , understanding of big data tech stack for instance data meshes , Spark jobs , Delta ,Apache Hudi ,Presto Engine nevertheless this paltform is highly scalable  and with the helm of few resource we can create two platform one



#Final Looks
![Big-data-Analytics-and-MLOps-Platform.png](Big-data-Analytics-and-MLOps-Platform.png)